# Off Grid AI UI

The React UI library for Off Grid AI. Animated, accessible components for local AI apps: chat, tool
calls, voice, PDFs and media, built on shadcn/ui, Radix and Tailwind CSS.

Off Grid AI Desktop (core and Pro) and the browser extension render through it: one set of
components, one skin and one motion layer, so every surface looks and moves the same way.

Package: `@offgrid/ui`. Desktop and the extension install it under the alias
`@offgrid/operator-ui`.

## What's in it

| Entry point                                                    | What you get                                                                                                     |
| -------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| `@offgrid/ui/operator`, `operator/*`                           | Product primitives: actions, forms, dialogs, sheets, tabs, menus, tables, lists, settings rows                   |
| `operator/ai-*`, `operator/elements/*`, `operator/workflows/*` | AI surfaces: messages, reasoning, tool timeline, prompt input, sources, citations, queue, voice capture          |
| `operator/alive`, `alive.css`, `alive-semantic.css`            | The conductor: one orchestrated layer for load, scroll, hover, press and drag. `AliveProvider` and `LivingField` |
| `operator/experience`, `operator/presence`                     | Screen transitions, page headers, live status, state pills, auto height                                          |
| `ogad/ui/*`, `ogad/skin.css`                                   | Drop-ins for Desktop's shadcn/Radix primitives, same APIs                                                        |
| `extension/*`, `extension/skin.css`                            | Drop-ins for the extension side panel                                                                            |
| `operator/coss/*`, `operator/magic/*`, `operator/animate-ui/*` | Sourced components restyled to the Off Grid theme (also `bits`, `motion`, `dice`, `media`, `elevenlabs`)         |
| `styles.css`, `desktop.css`                                    | Compiled styles. Import once at the app root                                                                     |

There is no root export. Import the surface you need.

## Use it

```tsx
import { AliveProvider } from "@offgrid/ui/operator/alive";
import { Button } from "@offgrid/ui/operator";
import "@offgrid/ui/styles.css";

export function App() {
  return (
    <AliveProvider>
      <Button>Save</Button>
    </AliveProvider>
  );
}
```

Install from a pinned commit:

```bash
npm install "@offgrid/operator-ui@github:off-grid-ai/ui-library#<sha>"
```

`styles.css` needs the `@offgrid/design` tokens. The peer is optional so hosts that ship their own
tokens, like the extension, install without overrides. It is not on a registry yet; this repo
vendors a checksummed copy in `fixtures/vendor/` for development.

## Adopting it in Desktop or the extension

Every change is a drop-in: no screen code changes. From the app's repository root:

```bash
git apply /path/to/ui-library/integration/ogad.patch       # Desktop
git apply /path/to/ui-library/integration/extension.patch  # extension
npm install
```

Then run the app's usual typecheck, lint, tests and build.

## Design direction

Calm, luminous, alive. Lean, never bulky. Icons over labels, thin rows, depth and light instead of
colour.

- [Design philosophy](docs/direction/DESIGN_PHILOSOPHY.md)
- [The library's bar](docs/DESIGN_PHILOSOPHY.md)
- [Desktop](docs/direction/OGAD_DESIGN.md) and [extension](docs/direction/EXTENSION_DESIGN.md)

## Develop

```bash
npm ci
npm run dev:desktop    # live preview at /desktop.html
npm run check          # format, lint, typecheck, coverage, build, Next fixture
npm run check:release  # check + clean-archive install + browser states in Chromium
```

`src/components/` is a reference gallery, not part of the package. The release check fails if any of
it ends up in the tarball.

## Licence

[AGPL-3.0-only](LICENSE), the same as Off Grid AI Desktop and the browser extension. Third-party
sources keep their own licences, listed in [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md) and
[`LICENSES/`](LICENSES/).
