# Third-party provenance

This repository is licensed under AGPL-3.0-only (see `LICENSE`). Third-party portions keep their
own licences. This file records the provenance that is known from source metadata.

## Production Button

The API and composition pattern in `src/operator/button.tsx` is derived from the shadcn/ui Button
concept referenced by this repository's component catalogue:

- Project: shadcn/ui
- Component reference: <https://ui.shadcn.com/docs/components/button>
- Source repository: <https://github.com/shadcn-ui/ui>
- Audited upstream revision: `4396d5b2a5ee4e2ad5705e9b2522f92112f811a0`
- Audited source: <https://github.com/shadcn-ui/ui/blob/4396d5b2a5ee4e2ad5705e9b2522f92112f811a0/apps/v4/registry/new-york-v4/ui/button.tsx>
- Upstream licence: MIT
- Upstream copyright notice: Copyright (c) 2023 shadcn

The MIT licence text is available at the audited upstream revision in
<https://github.com/shadcn-ui/ui/blob/4396d5b2a5ee4e2ad5705e9b2522f92112f811a0/LICENSE.md> and is included locally at
`LICENSES/shadcn-ui-MIT.txt`. Its notice and permission terms must be retained when a substantial
portion of that implementation is redistributed.

The Off Grid adaptation uses its own CSS class contract and adds loading, disabled-link, touch,
focus, reduced-motion, and brand-token behavior. Those changes do not erase the upstream
provenance.

## Preview catalogue

The modules under `src/components/` name their source families (including Aceternity, Animate UI,
Magic UI, Motion Primitives, shadcn/ui, Cult UI, Eldora UI, and others), and `src/data/components.ts`
contains source links. Those modules have not been audited component-by-component for licence or
production fitness. They are intentionally excluded from package exports. Before promoting any
preview, verify its exact source revision and licence and add the corresponding notice here.

## Sourced Desktop collection

The implementations under `src/sourced/` retain their upstream source URLs.
See `LICENSES/SOURCE_SHA256SUMS` for hashes of the original source bytes, and the
`source-manifest.json` files under `src/sourced/` for per-file sources.

| Source                                                            | Revision                                   | Included licence                       |
| ----------------------------------------------------------------- | ------------------------------------------ | -------------------------------------- |
| [SmoothUI](https://github.com/educlopez/smoothui)                 | `b6312bce2b6f2ed95d8a6e98a592857884f5ea9e` | `LICENSES/smoothui.txt` (MIT)          |
| [Animate UI](https://github.com/imskyleen/animate-ui)             | `efeb96ffd7a3b7a4868667e4ac3c346620fb3044` | `LICENSES/animateui.txt` (MIT)         |
| [Motion Primitives](https://github.com/ibelick/motion-primitives) | `120f64f6ca60348e251f929e9c81f11ccbe45eda` | `LICENSES/motion-primitives.txt` (MIT) |
| [Magic UI](https://github.com/magicuidesign/magicui)              | `85f97fd27b053339af74ba9dd4ca428ee25989fb` | `LICENSES/magicui.txt` (MIT)           |

The `packages/shadcn-ui` files copied from the pinned SmoothUI tree are derived
from shadcn/ui. Its notice is retained in `LICENSES/shadcn-ui-MIT.txt` in addition
to SmoothUI's licence. Animate UI also composes Radix/shadcn patterns. Published
runtime dependencies retain their own notices in their packages.

Local changes cover module paths, client/type boundaries, brand tokens, selected
accessibility and reduced-motion behavior, and removal of Sidebar cookie writes.
They do not remove the upstream copyright or permission requirements.

The compiled Desktop stylesheet also includes `tw-animate-css` 1.4.0 (MIT), the
source animation utilities used by the shadcn components. Its licence is retained
in `LICENSES/tw-animate-css.txt`. These supply the original enter, exit, fade,
zoom, and slide classes.

## Rich chat and media sources

- [Vercel AI Elements](https://github.com/vercel/ai-elements/tree/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd), revision `6a9d5b1822ffb10bba4bd97175f01edd7d8651cd`: Apache-2.0; licence retained in `LICENSES/ai-elements.txt`. The copied shadcn foundation also retains `LICENSES/shadcn-ui-MIT.txt`.
- [ElevenLabs UI](https://github.com/elevenlabs/ui/tree/23c31bd3088814215a8b5d0bfb56b327cad1a578), revision `23c31bd3088814215a8b5d0bfb56b327cad1a578`: MIT; licence retained in `LICENSES/elevenlabs.txt`.

Original source hashes are recorded in `LICENSES/SOURCE_SHA256SUMS`. Local changes adapt imports and TypeScript type-only import boundaries.

## Coss UI, Dice UI, and Kokonut UI

| Source                                                  | Revision                                   | Local files            | Included licence               |
| ------------------------------------------------------- | ------------------------------------------ | ---------------------- | ------------------------------ |
| [Coss UI](https://github.com/cosscom/ui)                | `81bbc46dcbc9f5d91dc8b391b0e63415e250314e` | `src/sourced/coss/`    | `LICENSES/coss-ui.txt` (MIT)   |
| [Origin UI](https://github.com/cosscom/ui)              | `81bbc46dcbc9f5d91dc8b391b0e63415e250314e` | `src/sourced/origin/`  | `LICENSES/coss-ui.txt` (MIT)   |
| [Dice UI](https://github.com/sadmann7/diceui)           | `040e842d4119260c22a59bf7e9d5cc3808e09efb` | `src/sourced/diceui/`  | `LICENSES/diceui.txt` (MIT)    |
| [Kokonut UI](https://github.com/kokonut-labs/kokonutui) | `484760acbb973947012cb554c91c742b1559275b` | `src/sourced/kokonut/` | `LICENSES/kokonutui.txt` (MIT) |

Coss uses mixed licences. The copied files come from `apps/ui/registry/default/`,
and the Origin UI event calendar from `apps/origin/registry/default/components/event-calendar/`.
The pinned [licensing map](https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/LICENSING.md)
identifies `apps/ui/` and `apps/origin/` as MIT, and the
[`apps/ui/package.json`](https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/package.json)
declares MIT. The original MIT notice is retained from
[`apps/origin/LICENSE.md`](https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/origin/LICENSE.md):
Copyright (c) 2025 coss.com; Originally Copyright (c) 2025 Origin UI.
No source from the AGPL `packages/ui/` tree is included in this collection.

Dice UI files come from `docs/registry/bases/base/`. Its pinned
[MIT licence](https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/LICENSE)
retains Copyright (c) 2024 Sadman Sakib. Local changes resolve module paths
and registry icon placeholders for this package.

Kokonut UI supplies ParticleButton, its Button dependency, and its `cn` utility.
Its pinned [MIT licence](https://github.com/kokonut-labs/kokonutui/blob/484760acbb973947012cb554c91c742b1559275b/LICENSE)
retains Copyright (c) 2025 kokonutUI. Local changes use package-relative imports
and Off Grid color tokens.

Original file checksums for all three families are in
`LICENSES/SOURCE_SHA256SUMS`. Their runtime dependencies keep their own
licences. This notice does not assign the upstream licences to unrelated files.

## React Virtuoso

`react-virtuoso@4.18.19` is consumed as an exact runtime dependency and re-exported
through `operator/virtual-list`. Only the MIT core is included, not the commercial
Message List package. Original license: `LICENSES/react-virtuoso.txt`.
Source: https://github.com/petyosi/react-virtuoso/tree/main/packages/react-virtuoso

## Document and image controls

Pinned runtime dependencies retain their original packages and licenses:

| Package                     | Version | License copy                                  |
| --------------------------- | ------- | --------------------------------------------- |
| yet-another-react-lightbox  | 3.32.2  | LICENSES/yet-another-react-lightbox.txt (MIT) |
| react-pdf                   | 9.2.1   | LICENSES/react-pdf.txt (MIT)                  |
| pdfjs-dist                  | 4.8.69  | LICENSES/pdfjs.txt (Apache-2.0)               |
| @uiw/react-codemirror       | 4.25.12 | LICENSES/react-codemirror.txt (MIT)           |
| @codemirror/view            | 6.43.14 | LICENSES/codemirror-view.txt (MIT)            |
| @codemirror/lang-javascript | 6.2.5   | LICENSES/codemirror-javascript.txt (MIT)      |

Runtime package integrity is recorded in `package-lock.json`; the PDF worker is copied
from the matching installed PDF.js version.

## CodeMirror multiline inline completion

`@marimo-team/codemirror-ai@0.3.9` is an exact runtime dependency under Apache-2.0.
Its original licence is retained in `LICENSES/codemirror-ai.txt`. The release maps
to [commit aee0ddd](https://github.com/marimo-team/codemirror-ai/tree/aee0dddb2424edb4617e0a68dfbd8963f093ef40).
`operator/media/inline-completion` uses its original multiline widget and commands.
The local adapter disables the document-only cache and guards host callbacks
against stale/aborted results. No upstream rendering implementation was copied or
replaced.

## shadcn charts and Recharts

The chart surface is from shadcn-ui/ui at `30a58d4498f270af1c1e981a7d78a15cf5740841` (`apps/v4/registry/new-york-v4/ui/chart.tsx`), MIT. See `LICENSES/shadcn-chart.txt`. Recharts 3.10.1 is MIT; see `LICENSES/recharts.txt`. Original source hashes are in `LICENSES/SOURCE_SHA256SUMS`.

## Inline video controls

`media-chrome@4.17.2` remains an exact MIT runtime dependency. The public
`operator/media/video-player` entry reexports its original React bindings and
composes the source controls around a native video element, following the
[official React example](https://www.media-chrome.org/docs/en/react/get-started).
Only source-supported theme variables are supplied. The original license is
retained in `LICENSES/media-chrome.txt`; its tarball integrity is recorded in
`src/sourced/media/source-manifest.json` and `package-lock.json`.
