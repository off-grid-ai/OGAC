# @offgrid/design

Canonical design tokens shared by Off Grid products. JavaScript consumers import typed token
objects from `@offgrid/design`; web surfaces import `@offgrid/design/tokens.css`.

Motion durations are functional timing tokens only:

- `MOTION.micro` / `--og-motion-micro` — 150ms state feedback.
- `MOTION.spinner` / `--og-motion-spinner` — 800ms continuous progress rotation.

Components may animate only properties allowed by the brand canon and must independently honor
`prefers-reduced-motion`. The token package supplies duration, not permission to animate.
