# Third-party provenance

This file records the provenance that is known from source metadata. It does not assign ownership
to this repository and it does not declare a licence for the repository as a whole.

## Production Button

The API and composition pattern in `src/operator/button.tsx` is derived from the shadcn/ui Button
concept referenced by this repository's component catalogue:

- Project: shadcn/ui
- Component reference: <https://ui.shadcn.com/docs/components/button>
- Source repository: <https://github.com/shadcn-ui/ui>
- Audited upstream revision: `4396d5b2a5ee4e2ad5705e9b2522f92112f811a0`
- Audited source: <https://github.com/shadcn-ui/ui/blob/4396d5b2a5ee4e2ad5705e9b2522f92112f811a0/apps/v4/registry/new-york-v4/ui/button.tsx>
- Upstream licence: MIT
- Upstream copyright notice: Copyright (c) 2023 shadcn

The MIT licence text is available at the audited upstream revision in
<https://github.com/shadcn-ui/ui/blob/4396d5b2a5ee4e2ad5705e9b2522f92112f811a0/LICENSE.md> and is included locally at
`LICENSES/shadcn-ui-MIT.txt`. Its notice and permission terms must be retained when a substantial
portion of that implementation is redistributed.

The Off Grid adaptation uses its own CSS class contract and adds loading, disabled-link, touch,
focus, reduced-motion, and brand-token behavior. Those changes do not erase the upstream
provenance.

## Preview catalogue

The modules under `src/components/` name their source families (including Aceternity, Animate UI,
Magic UI, Motion Primitives, shadcn/ui, Cult UI, Eldora UI, and others), and `src/data/components.ts`
contains source links. Those modules have not been audited component-by-component for licence or
production fitness. They are intentionally excluded from package exports. Before promoting any
preview, verify its exact source revision and licence and add the corresponding notice here.
