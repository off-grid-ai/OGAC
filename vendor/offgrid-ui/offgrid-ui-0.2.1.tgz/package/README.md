# @offgrid/ui

The shared production component package for Off Grid products. It is curated from the component
catalogue in this repository, then adapted to the canonical Off Grid brand and held to production
accessibility, reduced-motion, test, and framework-compatibility gates.

The many gallery modules under `src/components/` are **reference previews**, not production
components. They are not package exports and must not be copied into a product. A preview becomes
reusable only after it is moved behind one of the explicit production surfaces below and passes the
package gates.

## Production surfaces

- `@offgrid/ui/operator` — dense product and operator-console primitives. Currently exports
  `Button` and `buttonVariants`.
- `@offgrid/ui/marketing` — intentionally empty until a marketing primitive passes curation. This
  prevents decorative gallery demos from becoming an accidental API.
- `@offgrid/ui/styles.css` — shared component styles. Import it once in a product root after
  installing the `@offgrid/design` peer.

There is deliberately no package-root component export. Consumers must select the operator or
marketing surface explicitly.

```tsx
import { Button } from "@offgrid/ui/operator";
import "@offgrid/ui/styles.css";

export function SaveAction() {
  return <Button loading={false}>Save policy</Button>;
}
```

For Next.js, global CSS belongs in the application root layout. `Button` owns a narrow `use client`
boundary; a Server Component can render it with serializable props, while event handlers remain in
a Client Component. `fixtures/next-app` is the build fixture for both paths.

## Button provenance and selection

The production Button extends the repository's shadcn-style Button concept and the stronger Off
Grid Console interaction contract. It was selected over the animated, stateful, texture, gradient,
and 3D button demos because an operator action needs complete semantics and quiet state feedback,
not ornamental motion. The public API keeps shadcn's `asChild`, variants, and sizes; the extension
adds safe default button type, native and slotted disabled behavior, loading semantics, stable
labels, touch sizing, focus visibility, and a reduced-motion path.

Visual rules come from `@offgrid/design`: Menlo, monochrome surfaces, one emerald accent, semantic
red only for destructive actions, flat composition, and transform/opacity-only motion. Component
semantic tokens in `src/styles.css` fill control-specific gaps (control height, focus width, and
press scale) without copying the shared palette, typography, or motion durations.

## Development gates

```bash
npm ci
npm run check
npm run check:release # clean archive + styled browser-state verification
npm run build:catalogue # optional preview-gallery regression check
```

`npm run check` runs formatting, package-scoped lint, typecheck, ≥85% coverage, dependency-boundary
and runtime audit gates, the production package build, and the real Next 15 fixture build.
`npm run check:release` additionally proves `prepare`/`prepack` from a clean Git archive, installs
the resulting tarball with the required design peer, verifies every export target, and exercises
light, dark, focus, loading, disabled, coarse-pointer, reduced-motion, and client-hydration states
in Chromium.

The shipped runtime dependency audit is clean. The development tree currently reports two
moderate advisories because the required Next 15 fixture bundles an older PostCSS internally;
there is no non-breaking Next 15 resolution published by npm. The fixture is not included in the
package tarball, and the runtime gate remains `npm audit --omit=dev`.

The catalogue has a separate `lint:catalogue` gate because its preview modules have not yet been
production-curated. Passing the package gate does not bless those previews.

The inherited preview application does not currently pass `npm run build:catalogue`: its
`LightGreenLandingPage.tsx` has seven pre-existing unused declarations. That failure is outside the
curated package graph and is not hidden by `npm run check`; it remains a catalogue-maintenance
blocker before the gallery itself can be described as healthy.

## Distribution and token blocker

The package uses the stable peer name `@offgrid/design` and imports
`@offgrid/design/tokens.css`; it does not encode a developer-machine `file:` path. The current
design package is private and not published to a registry, so products must provide it from the Off
Grid workspace. Publishing `@offgrid/design` (or establishing one private workspace/registry) is
required before this package can be installed independently from npm. The peer is required. This
repository installs an exact, checksummed design-package artifact from `fixtures/vendor/` only for
reproducible development and verification; that fixture is excluded from the UI package tarball.

This repository has no declared top-level licence or ownership notice. `package.json` therefore
uses `UNLICENSED` and remains private. Do not publish it until the repository owner supplies the
licence. Component-level provenance is recorded in `THIRD_PARTY_NOTICES.md`.

The release-safe, unpublished Console consumption contract is documented in
[`docs/CONSOLE_CONSUMPTION.md`](docs/CONSOLE_CONSUMPTION.md). It requires exact source revisions,
deterministic tarballs, committed SHA-256 verification, and an explicit licensing authorization;
it never relies on a developer-machine sibling path.
